// JavaScript commun pour l'application Cinema Palace
// Note: La plupart des fonctions ont été déplacées vers unused-functions.js car elles ne sont pas utilisées actuellement

// Initialisation commune minimale
document.addEventListener('DOMContentLoaded', function() {
    console.log('Application Cinema Palace initialisée');
});
